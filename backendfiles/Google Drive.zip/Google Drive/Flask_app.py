# from flask import Flask, redirect, url_for, session, request, render_template
# from google.oauth2.credentials import Credentials
# from google_auth_oauthlib.flow import Flow
# from googleapiclient.discovery import build
# import io
# from googleapiclient.http import MediaIoBaseDownload
# import os

# app = Flask(__name__)
# app.secret_key = 'your_secret_key'  # Replace with a secure key
# os.environ['OAUTHLIB_INSECURE_TRANSPORT'] = '1'

# # Path to your credentials.json file
# CLIENT_SECRETS_FILE = "credentials.json"

# # Scopes for Google Drive
# SCOPES = ['https://www.googleapis.com/auth/drive']

# # API version and service
# API_SERVICE_NAME = 'drive'
# API_VERSION = 'v3'


# @app.route('/')
# def index():
#     """Home route to start authentication."""
#     return 'Welcome to the Google Drive Downloader! <a href="/authorize">Authorize</a>'


# @app.route('/authorize')
# def authorize():
#     """Start the OAuth 2.0 flow."""
#     flow = Flow.from_client_secrets_file(
#         CLIENT_SECRETS_FILE,
#         scopes=SCOPES,
#         redirect_uri=url_for('oauth2callback', _external=True)
#     )
#     auth_url, _ = flow.authorization_url(prompt='consent')
#     return redirect(auth_url)


# @app.route('/oauth2callback')
# def oauth2callback():
#     """Handle the callback from Google's OAuth 2.0 server."""
#     flow = Flow.from_client_secrets_file(
#         CLIENT_SECRETS_FILE,
#         scopes=SCOPES,
#         redirect_uri=url_for('oauth2callback', _external=True)
#     )
#     flow.fetch_token(authorization_response=request.url)

#     # Store credentials in session
#     credentials = flow.credentials
#     session['credentials'] = {
#         'token': credentials.token,
#         'refresh_token': credentials.refresh_token,
#         'token_uri': credentials.token_uri,
#         'client_id': credentials.client_id,
#         'client_secret': credentials.client_secret,
#         'scopes': credentials.scopes
#     }
#     return redirect(url_for('files'))


# @app.route('/files')
# def files():
#     """List files in the user's Google Drive."""
#     credentials = Credentials(**session['credentials'])

#     drive_service = build(API_SERVICE_NAME, API_VERSION, credentials=credentials)
#     results = drive_service.files().list(pageSize=10, fields="files(id, name)").execute()
#     items = results.get('files', [])

#     # Save updated credentials
#     session['credentials'] = credentials_to_dict(credentials)

#     return render_template('files.html', items=items)


# @app.route('/download/<file_id>')
# def download(file_id):
#     """Download a specific file."""
#     credentials = Credentials(**session['credentials'])

#     drive_service = build(API_SERVICE_NAME, API_VERSION, credentials=credentials)
#     request = drive_service.files().get_media(fileId=file_id)

#     # Download file
#     file_name = f"downloaded_file_{file_id}"
#     with open(file_name, 'wb') as f:
#         downloader = MediaIoBaseDownload(f, request)
#         done = False
#         while not done:
#             status, done = downloader.next_chunk()

#     return f'File {file_name} downloaded successfully!'


# def credentials_to_dict(credentials):
#     """Convert Credentials object to a dictionary."""
#     return {
#         'token': credentials.token,
#         'refresh_token': credentials.refresh_token,
#         'token_uri': credentials.token_uri,
#         'client_id': credentials.client_id,
#         'client_secret': credentials.client_secret,
#         'scopes': credentials.scopes
#     }


# if __name__ == '__main__':
#     app.run('localhost', 5108, debug=True)
#-----------------------------------------------------------------------------------------------------------------------------------------------------------------


from flask import Flask, redirect, url_for, session, request, render_template
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import Flow
from googleapiclient.discovery import build
import io
from googleapiclient.http import MediaIoBaseDownload
import os

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Replace with a secure key
os.environ['OAUTHLIB_INSECURE_TRANSPORT'] = '1'

# Path to your credentials.json file
CLIENT_SECRETS_FILE = "credentials.json"

# Scopes for Google Drive
SCOPES = ['https://www.googleapis.com/auth/drive']

# API version and service
API_SERVICE_NAME = 'drive'
API_VERSION = 'v3'


@app.route('/')
def index():
    """Home route to start authentication."""
    return 'Welcome to the Google Drive Downloader! <a href="/authorize">Authorize</a>'


@app.route('/authorize')
def authorize():
    """Start the OAuth 2.0 flow."""
    flow = Flow.from_client_secrets_file(
        CLIENT_SECRETS_FILE,
        scopes=SCOPES,
        redirect_uri=url_for('oauth2callback', _external=True)
    )
    auth_url, _ = flow.authorization_url(prompt='consent')
    return redirect(auth_url)


@app.route('/oauth2callback')
def oauth2callback():
    """Handle the callback from Google's OAuth 2.0 server."""
    flow = Flow.from_client_secrets_file(
        CLIENT_SECRETS_FILE,
        scopes=SCOPES,
        redirect_uri=url_for('oauth2callback', _external=True)
    )
    flow.fetch_token(authorization_response=request.url)

    # Store credentials in session
    credentials = flow.credentials
    session['credentials'] = {
        'token': credentials.token,
        'refresh_token': credentials.refresh_token,
        'token_uri': credentials.token_uri,
        'client_id': credentials.client_id,
        'client_secret': credentials.client_secret,
        'scopes': credentials.scopes
    }
    return redirect(url_for('files'))


@app.route('/files')
def files():
    """List files in the user's Google Drive."""
    credentials = Credentials(**session['credentials'])

    drive_service = build(API_SERVICE_NAME, API_VERSION, credentials=credentials)
    results = drive_service.files().list(pageSize=10, fields="files(id, name)").execute()
    items = results.get('files', [])

    # Save updated credentials
    session['credentials'] = credentials_to_dict(credentials)

    return render_template('files.html', items=items)


@app.route('/download/<file_id>')
def download(file_id):
    """Download a specific file by its ID and save it with the actual filename."""
    credentials = Credentials(**session['credentials'])

    drive_service = build(API_SERVICE_NAME, API_VERSION, credentials=credentials)

    # Get the file metadata to retrieve the file name
    file_metadata = drive_service.files().get(fileId=file_id, fields="name").execute()
    file_name = file_metadata['name']

    # Request the file to be downloaded
    request = drive_service.files().get_media(fileId=file_id)

    # Download file and save it with the correct name
    file_path = os.path.join('downloads', file_name)
    if not os.path.exists('downloads'):
        os.makedirs('downloads')

    with open(file_path, 'wb') as f:
        downloader = MediaIoBaseDownload(f, request)
        done = False
        while not done:
            status, done = downloader.next_chunk()

    return f'File {file_name} downloaded successfully!'


def credentials_to_dict(credentials):
    """Convert Credentials object to a dictionary."""
    return {
        'token': credentials.token,
        'refresh_token': credentials.refresh_token,
        'token_uri': credentials.token_uri,
        'client_id': credentials.client_id,
        'client_secret': credentials.client_secret,
        'scopes': credentials.scopes
    }


if __name__ == '__main__':
    app.run('localhost', 5108, debug=True)
